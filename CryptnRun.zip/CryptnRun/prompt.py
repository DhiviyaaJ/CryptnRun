import tkinter as tk
from tkinter import simpledialog

root = tk.Tk()
root.withdraw()

user_input = simpledialog.askstring(title="Input", prompt="Please enter some text:")

print("You entered:", user_input)
