from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import base64

# Define the key and message to encrypt
key = b'Sixteen byte key'
message = b'dhivyaabharathi!'

# Pad the message to a multiple of 16 bytes (the block size for AES)
padded_message = pad(message, AES.block_size)

# Create an AES cipher object with the key and mode (CBC or ECB)
cipher = AES.new(key, AES.MODE_CBC)

# Encrypt the padded message
ciphertext = cipher.encrypt(padded_message)

# Encode the ciphertext as a base64 string
cipher_text_b64 = base64.b64encode(ciphertext)

# Print the encrypted ciphertext as a hex string
print("Encrypted ciphertext: ", cipher_text_b64)

# Prompt the player to enter the cipher text to unlock the first key
# input_cipher_text = input("Enter the cipher text to unlock the first key: ")

# # Decode the input cipher text from base64 to bytes
input_cipher_text_bytes = base64.b64decode( cipher_text_b64)

# # Check if the input cipher text matches the original cipher text
# if input_cipher_text_bytes == ciphertext:
#     print("First key unlocked!")
    
    # Prompt the player to enter the key size to unlock the second key
input_key_size = int(input("Enter the key size used for encryption: "))
    
    # Check if the input key size matches the expected size
# if input_key_size == len(key) * 8:
        # print("Second key unlocked!")
        
        # Prompt the player to enter the key password to decrypt the message and unlock the third key
# input_key_password = input("Enter the key to decrypt the message: ")
input_key_password = b'Sixteen Byte key'
        
        # Check if the input key password matches the original key
        # if input_key_password.encode() == key:
        #     print("Third key unlocked!")
            
        #     # Create an AES cipher object with the key and mode (CBC or ECB)
        #     cipher = AES.new(key, AES.MODE_CBC, iv=cipher.iv)

            # Decrypt the ciphertext
decrypted_message = unpad(cipher.decrypt(input_cipher_text_bytes), AES.block_size)

            # Print the decrypted message
print("Decrypted message: ", decrypted_message)
#         else:
#             print("Incorrect key password. Try again!")
#     else:
#         print("Incorrect key size. Try again!")
# else:
#     print("Incorrect cipher text. Try again!")